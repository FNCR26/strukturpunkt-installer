#!/bin/bash

# Strukturpunkt Public Installer - Downloads from Registry
set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
REGISTRY="registry.strukturpunkt.info"
UPDATE_INTERVAL=${UPDATE_INTERVAL:-60}
INSTALL_DIR="/opt/strukturpunkt"

echo -e "${BLUE}╔═══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Strukturpunkt Installer (Public)        ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════╝${NC}"

# Check if running on Raspberry Pi
check_raspberry() {
    if [[ -f /proc/device-tree/model ]]; then
        MODEL=$(cat /proc/device-tree/model)
        if [[ $MODEL == *"Raspberry Pi"* ]]; then
            echo -e "${GREEN}✓ Running on: $MODEL${NC}"
            return 0
        fi
    fi
    echo -e "${YELLOW}⚠ Warning: Not running on Raspberry Pi${NC}"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]]
}

# Install Docker if needed
install_docker() {
    if ! command -v docker &> /dev/null; then
        echo -e "${YELLOW}Installing Docker...${NC}"
        curl -sSL https://get.docker.com | sh
        sudo usermod -aG docker $USER
        echo -e "${GREEN}✓ Docker installed${NC}"
        echo -e "${YELLOW}Please logout and login again for docker permissions${NC}"
    else
        echo -e "${GREEN}✓ Docker already installed${NC}"
    fi
}

# Install docker-compose
install_compose() {
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        echo -e "${YELLOW}Installing docker-compose...${NC}"
        sudo apt-get update
        sudo apt-get install -y docker-compose-plugin
        echo -e "${GREEN}✓ Docker Compose installed${NC}"
    else
        echo -e "${GREEN}✓ Docker Compose already installed${NC}"
    fi
}

# Choose MongoDB version
choose_mongo_version() {
    echo -e "\n${BLUE}MongoDB Version wählen:${NC}"
    echo "1) MongoDB 7 (neueste - kann auf älteren Pi crashen)"
    echo "2) MongoDB 4.0 (kompatibel mit allen Pi - empfohlen)"
    echo "3) Automatisch testen"
    echo ""
    
    while true; do
        read -p "Auswahl [1-3]: " choice
        case $choice in
            1)
                MONGO_VERSION="7"
                echo -e "${YELLOW}MongoDB 7 gewählt${NC}"
                break
                ;;
            2)
                MONGO_VERSION="4.0"
                echo -e "${GREEN}MongoDB 4.0 gewählt (empfohlen)${NC}"
                break
                ;;
            3)
                echo -e "${YELLOW}Teste MongoDB Kompatibilität...${NC}"
                if docker run --rm mongo:7 mongod --version >/dev/null 2>&1; then
                    MONGO_VERSION="7"
                    echo -e "${GREEN}✓ MongoDB 7 kompatibel${NC}"
                else
                    MONGO_VERSION="4.0"
                    echo -e "${YELLOW}⚠ MongoDB 7 nicht kompatibel, verwende 4.0${NC}"
                fi
                break
                ;;
            *)
                echo "Bitte 1, 2 oder 3 wählen"
                ;;
        esac
    done
}

# Setup application
setup_app() {
    echo -e "\n${YELLOW}Setting up Strukturpunkt...${NC}"
    
    choose_mongo_version
    
    sudo mkdir -p $INSTALL_DIR
    sudo chown $USER:$USER $INSTALL_DIR
    cd $INSTALL_DIR
    
    # Create docker-compose.yml - pulls from your private registry
    cat > docker-compose.yml << EOF
version: '3.9'

services:
  mongo:
    image: mongo:$MONGO_VERSION
    container_name: strukturpunkt-mongo
    volumes:
      - ./mongo-data:/data/db
    environment:
      - MONGO_INITDB_ROOT_USERNAME=\${MONGO_ROOT_USER:-admin}
      - MONGO_INITDB_ROOT_PASSWORD=\${MONGO_ROOT_PASS}
      - MONGO_INITDB_DATABASE=strukturpunkt
    restart: unless-stopped
    networks:
      - strukturpunkt-network
    mem_limit: 512m
    cpus: 0.5

  backend:
    image: $REGISTRY/strukturpunkt-backend:latest
    container_name: strukturpunkt-backend
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=production
      - MONGO_URI=mongodb://\${MONGO_ROOT_USER:-admin}:\${MONGO_ROOT_PASS}@mongo:27017/strukturpunkt?authSource=admin
      - JWT_SECRET=\${JWT_SECRET}
      - API_KEY=\${API_KEY}
    depends_on:
      - mongo
    restart: unless-stopped
    networks:
      - strukturpunkt-network
    mem_limit: 256m
    cpus: 0.5

  frontend:
    image: $REGISTRY/strukturpunkt-frontend:latest
    container_name: strukturpunkt-frontend
    ports:
      - "80:80"
    restart: unless-stopped
    networks:
      - strukturpunkt-network
    mem_limit: 128m
    cpus: 0.3

networks:
  strukturpunkt-network:
    driver: bridge
EOF

    # Generate secure secrets
    cat > .env << EOF
# Generated secrets - DO NOT SHARE!
MONGO_ROOT_USER=admin
MONGO_ROOT_PASS=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
JWT_SECRET=$(openssl rand -base64 64 | tr -d "=+/" | cut -c1-50)
API_KEY=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-32)
EOF
    
    chmod 600 .env
    echo -e "${GREEN}✓ Configuration created${NC}"
}

# Create auto-update script
create_update_script() {
    cat > $INSTALL_DIR/auto-update.sh << EOF
#!/bin/bash
set -e

BACKEND_IMAGE="$REGISTRY/strukturpunkt-backend:latest"
FRONTEND_IMAGE="$REGISTRY/strukturpunkt-frontend:latest"
UPDATED=false

echo "[$(date)] Checking for updates..."

if docker pull \$BACKEND_IMAGE | grep -q "Downloaded newer image"; then
    echo "Backend updated!"
    UPDATED=true
fi

if docker pull \$FRONTEND_IMAGE | grep -q "Downloaded newer image"; then
    echo "Frontend updated!"
    UPDATED=true
fi

if [ "\$UPDATED" = true ]; then
    echo "Restarting services..."
    cd $INSTALL_DIR
    docker compose down
    docker compose up -d
    echo "Update complete!"
    docker image prune -f
else
    echo "No updates available"
fi
EOF
    
    chmod +x $INSTALL_DIR/auto-update.sh
    echo -e "${GREEN}✓ Update script created${NC}"
}

# Setup systemd auto-update service
setup_auto_update() {
    echo -e "\n${YELLOW}Setting up auto-update (every $UPDATE_INTERVAL seconds)...${NC}"
    
    sudo tee /etc/systemd/system/strukturpunkt-update.service > /dev/null << EOF
[Unit]
Description=Strukturpunkt Auto-Update
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
ExecStart=$INSTALL_DIR/auto-update.sh
WorkingDirectory=$INSTALL_DIR
StandardOutput=journal
StandardError=journal
EOF

    sudo tee /etc/systemd/system/strukturpunkt-update.timer > /dev/null << EOF
[Unit]
Description=Run Strukturpunkt Update every $UPDATE_INTERVAL seconds
Requires=strukturpunkt-update.service

[Timer]
OnBootSec=60
OnUnitActiveSec=${UPDATE_INTERVAL}s
AccuracySec=10s

[Install]
WantedBy=timers.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable strukturpunkt-update.timer
    sudo systemctl start strukturpunkt-update.timer
    
    echo -e "${GREEN}✓ Auto-update configured${NC}"
}

# Main installation
main() {
    check_raspberry
    
    echo -e "\n${YELLOW}Installing prerequisites...${NC}"
    # Fix any broken packages first
    sudo apt --fix-broken install -y || true
    sudo apt-get update
    sudo apt-get install -y curl jq openssl
    
    install_docker
    install_compose
    setup_app
    create_update_script
    setup_auto_update
    
    # Registry login required
    echo -e "\n${YELLOW}Registry login required...${NC}"
    echo -e "${BLUE}Please enter your Strukturpunkt registry credentials:${NC}"
    docker login $REGISTRY
    
    # Initial start
    echo -e "\n${YELLOW}Starting Strukturpunkt...${NC}"
    cd $INSTALL_DIR
    docker compose pull
    docker compose up -d
    
    # Show status
    echo -e "\n${GREEN}✓ Installation complete!${NC}"
    echo -e "\n${YELLOW}Access URLs:${NC}"
    IP=$(hostname -I | awk '{print $1}')
    echo -e "Frontend: ${BLUE}http://$IP${NC}"
    echo -e "Backend API: ${BLUE}http://$IP:3001${NC}"
    
    echo -e "\n${YELLOW}Use 'strukturpunkt' command for management${NC}"
}

main "$@"