#!/bin/bash

# Strukturpunkt Database Backup Script
set -e

INSTALL_DIR="/opt/strukturpunkt"
BACKUP_DIR="/opt/strukturpunkt/backups"
DATE=$(date +%Y%m%d_%H%M%S)

echo "Creating backup..."

mkdir -p $BACKUP_DIR

# Stop containers for consistent backup
cd $INSTALL_DIR
docker compose stop backend frontend

# Backup MongoDB data
tar -czf $BACKUP_DIR/mongo_backup_$DATE.tar.gz -C $INSTALL_DIR mongo-data/

# Backup config
cp .env $BACKUP_DIR/env_backup_$DATE

# Restart containers
docker compose start backend frontend

echo "✓ Backup created: $BACKUP_DIR/mongo_backup_$DATE.tar.gz"